Configuration
=============================

In this section are described all informations about the core of platform

.. toctree::
   :maxdepth: 2


   org/geosdi/geoplatform/gui/index


