Handlers and Events for menu' item check
========================================

In this section are described all informations about the core of platform

.. toctree::
   

   handler/index
   event/index