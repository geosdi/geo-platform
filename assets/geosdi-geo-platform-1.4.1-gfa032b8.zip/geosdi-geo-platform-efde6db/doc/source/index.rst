Geo-Platform Developer Manual
==========================

Welcome to the Geo-Platform Developer Manual.  The manual is for those who want to help with the development process, including source code, software releasing, and other administrative work.

.. toctree::
   :maxdepth: 2


   geoplatform-gui/core/index


