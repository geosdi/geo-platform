.. _plugin:

Plugin
========

This section details the plugin subsystem in Geo-Platform.

.. toctree::
   :maxdepth: 2

   plugin_proj
