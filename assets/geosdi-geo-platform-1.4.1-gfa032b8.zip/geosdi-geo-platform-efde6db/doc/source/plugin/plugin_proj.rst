.. _plugin_proj:

Write new Geo-Platform Plugin
===========================

